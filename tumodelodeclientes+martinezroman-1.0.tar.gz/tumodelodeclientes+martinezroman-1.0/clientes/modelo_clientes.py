class Cliente:
    contador_clientes = 0  # Atributo de clase para llevar la cuenta de los clientes y asignar id único en forma correlativa
    clientes_registrados = []  # Lista para almacenar todos los clientes creados

    def __init__(self, nombre: str, apellido: str, edad: int, direccion: str, telefono: str, sede_inscripcion: str, actividades_preferidas: list[str] = None):
        Cliente.contador_clientes += 1
        self.id_cliente = f"{Cliente.contador_clientes:04d}"
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self._direccion = direccion # atributo protegido
        self._telefono = telefono # atributo protegido
        self.sede_inscripcion = sede_inscripcion
        self.actividades_preferidas = actividades_preferidas if actividades_preferidas else ["Sin selección"]

        Cliente.clientes_registrados.append(self)

    def __str__(self):
        actividades = ", ".join(self.actividades_preferidas)
        return (f"\n***DATOS DEL CLIENTE***\n"
                f"Número de cliente: {self.id_cliente}\n"
                f"Nombre: {self.nombre}\n"
                f"Apellido: {self.apellido}\n"
                f"Edad: {self.edad}\n"
                f"Sede: {self.sede_inscripcion}\n"
                f"Actividades preferidas: {actividades}\n")

    def mostrar_datos_de_contacto(self):
        """Muestra los datos de contacto protegidos del cliente."""
        return (f"Dirección: {self._direccion}\n"
                f"Teléfono: {self._telefono}\n")

    def modificar_datos_de_contacto(self, nueva_direccion: str, nuevo_telefono: str):
        """Modifica los datos de contacto protegidos del cliente"""
        self._direccion = nueva_direccion
        self._telefono = nuevo_telefono

    def resumen(self) -> str:
        es_corporativo = "SI" if isinstance(self, ClienteCorporativo) else "NO"
        return f"{self.id_cliente} - {self.nombre} {self.apellido} ({self.edad} años) - Sede: {self.sede_inscripcion} - Cliente corporativo: {es_corporativo}"

    @classmethod
    def resumen_clientes_registrados(cls) -> str:
        if not cls.clientes_registrados:
            return "No hay clientes registrados aún."
        return "\n".join(cliente.resumen() for cliente in cls.clientes_registrados)


class ClienteCorporativo(Cliente):
    def __init__(self, nombre: str, apellido: str, edad: int, direccion: str, telefono: str, sede_inscripcion: str, empresa: str, codigo_paquete_de_beneficios: str, actividades_preferidas: list[str] = None):
        super().__init__(nombre, apellido, edad, direccion, telefono, sede_inscripcion, actividades_preferidas)
        self.empresa = empresa
        self.codigo_paquete_de_beneficios = codigo_paquete_de_beneficios

    def __str__(self):
        return (super().__str__() +
                f"*CLIENTE CORPORATIVO*\n"
                f"Empresa: {self.empresa}\n"
                f"Código de paquete de beneficios: {self.codigo_paquete_de_beneficios}\n")