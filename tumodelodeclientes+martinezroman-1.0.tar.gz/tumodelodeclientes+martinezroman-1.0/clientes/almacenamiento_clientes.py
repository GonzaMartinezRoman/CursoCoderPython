import json
from .modelo_clientes import Cliente

ARCHIVO_JSON = "clientes.json"

def guardar_clientes():
    """Guarda los clientes en un archivo JSON."""
    with open(ARCHIVO_JSON, "w") as archivo:
        json.dump([cliente.__dict__ for cliente in Cliente.clientes_registrados], archivo, indent=4)

# def cargar_clientes():
#     """Carga los clientes desde un archivo JSON."""
#     try:
#         with open(ARCHIVO_JSON, "r") as archivo:
#             datos = json.load(archivo)
#             for cliente in datos:
#                 if "empresa" in cliente:
#                     ClienteCorporativo(**cliente)
#                 else:
#                     Cliente(**cliente)
#     except FileNotFoundError:
#         pass  # Si el archivo no existe, no hace nada