from setuptools import setup

setup(
    name= "TuModeloDeClientes+MartinezRoman",
    description= "paquete para gestionar clientes del gimnasio",
    version= "1.0",
    author= "Gonzalo Martinez Roman",
    author_email= "martinezromang@gmail.com",

    packages= ["clientes"]
)
